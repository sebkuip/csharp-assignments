﻿namespace assignment1
{
    public enum Speciality
    {
        Java,
        Csharp,
        HTML,
        PHP,
        Unknown,
    }
}
