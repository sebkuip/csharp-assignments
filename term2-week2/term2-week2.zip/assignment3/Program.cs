﻿namespace assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }

        enum RegularCandies
        {
            red = ConsoleColor.Red,
            orange = ConsoleColor.DarkYellow,
            yellow = ConsoleColor.Yellow,
            green = ConsoleColor.Green,
            blue = ConsoleColor.Blue,
            purple = ConsoleColor.Magenta,
        }

        void Start ()
        {
            RegularCandies[,] playingField = new RegularCandies[11,11];
            InitCandies(ref playingField);
            DisplayCandies(playingField);
            bool rowScore = ScoreRowPresent(playingField);
            bool columnScore = ScoreColumnPresent(playingField);

            Console.WriteLine();
            if (rowScore)
            {
                Console.WriteLine("row score");
            } else
            {
                Console.WriteLine("no row score");
            }

            if (columnScore)
            {
                Console.WriteLine("column score");
            } else
            {
                Console.WriteLine("no column score");
            }
        }

        void InitCandies(ref RegularCandies[,] playingField)
        {
            Array values = Enum.GetValues(typeof(RegularCandies));
            Random random = new Random(9);
            for (int i = 0; i < playingField.GetLength(0); i++)
            {
                for (int j = 0; j < playingField.GetLength(1); j++)
                {
                    playingField[i,j] = playingField[i, j] = (RegularCandies)values.GetValue(random.Next(values.Length));
                }
            }
        }

        void DisplayCandies(RegularCandies[,] playingField)
        {
            for (int i = 0; i < playingField.GetLength(0); i++)
            {
                for (int j = 0; j < playingField.GetLength(1); j++)
                {
                    Console.ForegroundColor = (ConsoleColor)playingField[i,j];
                    Console.Write("# ");
                }
                Console.WriteLine();
            }
            Console.ResetColor();
        }

        bool ScoreRowPresent(RegularCandies[,] playingField)
        {
            int counter = 1;
            for (int i = 0; i < playingField.GetLength(0); i++)
            {
                RegularCandies currentCandy = playingField[i,0];
                for (int j = 0; j < playingField.GetLength(1); j++)
                {
                    if (currentCandy.Equals(playingField[i, j]))
                    {
                        counter++;
                        if (counter == 3)
                        {
                            return true;
                        }
                    } else
                    {
                        counter = 1;
                        currentCandy = playingField[i, j];
                    }
                }
            }
            return false;
        }

        bool ScoreColumnPresent(RegularCandies[,] playingField)
        {
            int counter = 1;
            for (int i = 0; i < playingField.GetLength(1); i++)
            {
                RegularCandies currentCandy = playingField[i,0];
                for (int j = 0; j < playingField.GetLength(0); j++)
                {
                    if (currentCandy.Equals(playingField[j, i]))
                    {
                        counter++;
                        if (counter == 3)
                        {
                            return true;
                        }
                    }
                    else
                    {
                        counter = 1;
                        currentCandy = playingField[j, i];
                    }
                }
            }
            return false;
        }
    }
}
