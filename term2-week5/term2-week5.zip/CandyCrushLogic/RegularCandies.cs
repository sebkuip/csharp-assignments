﻿namespace CandyCrushLogic
{
    public enum RegularCandies
    {
        red = ConsoleColor.Red,
        orange = ConsoleColor.DarkYellow,
        yellow = ConsoleColor.Yellow,
        green = ConsoleColor.Green,
        blue = ConsoleColor.Blue,
        purple = ConsoleColor.Magenta,
    }
}
