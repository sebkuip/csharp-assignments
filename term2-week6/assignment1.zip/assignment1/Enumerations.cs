﻿namespace assignment1
{
    public enum ChessPieceColor
    {
        White,
        Black,
    }

    public enum ChessPieceType
    {
        Pawn,
        Rook,
        Knight,
        Bishop,
        King,
        Queen,
    }
}
