﻿namespace assignment1
{
    public class ChessPiece
    {
        public ChessPieceColor color;
        public ChessPieceType type;

        public ChessPiece(ChessPieceColor color, ChessPieceType type)
        {
            this.color = color;
            this.type = type;
        }
    }

}
